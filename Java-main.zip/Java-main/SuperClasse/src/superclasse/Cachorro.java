
package superclasse;

public class Cachorro extends Animal {
    
    public Cachorro(String nome, String raca) {
        super(nome);
    }
    
    
}
