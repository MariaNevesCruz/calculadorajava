
package superclasse;

public class Corvo extends Animal{
    
    public Corvo(String nome) {
        super(nome);
    }
    
   
    public void fazerBarulho(){
        System.out.println( "croack croack");
    
}
}