
package superclasse;

public class Galinha extends Animal{
    
    public Galinha(String nome) {
        super(nome);
    }
    
    
    public void fazerBarulho(){
        System.out.println( "popopo");
  
    
    
}
}