public class Nome {
    public static void main(String[]args)throws Exception{
        //declaração de variável
        String nome = "Julia";
        //sinal de + é igual aconcatenar "juntar"
        System.out.println("Seu nome é :" + nome);
    }
    
}
