public class Informacao {
    public static void main(String []args) throws Exception{

        String nome = "Julia";
        int idade = 18;
        float altura = 1.65f;
        boolean aprovar = true;

        System.out.println("O seu nome é:" + nome + "\n" + "Sua idade é:" + idade + "\n"+ "Sua altura é:" + altura + "\n" + "Aprovada:" + aprovar);


    }
    
}
