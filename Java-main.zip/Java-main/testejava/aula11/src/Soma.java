public class Soma {
    public static void main  (String[]args)throws Exception{

        int valor1 = 10;
        int valor2 = 10;

        int resultado = valor1 + valor2;

         System.out.println("O resultado é:"+ resultado);
    }
    
}
