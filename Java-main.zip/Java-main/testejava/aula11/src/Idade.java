public class Idade {
    public static void main(String[]args)throws Exception{
        int idade = 18;
        double valor = 5.5;
        System.out.println("A sua idade é :"+ idade + "O valor é:" + valor);
    }
    
}
